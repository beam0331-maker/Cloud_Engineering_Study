package com.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.config.MySqlSessionFactory;
import com.dao.BoardDAO;
import com.dto.BoardDTO;

public class BoardServiceImpl implements BoardService {
	
	BoardDAO dao;
	@Override
	public void setDao(BoardDAO dao) {
		this.dao = dao;
	}
	
	@Override
	public List<BoardDTO> list() {
		List<BoardDTO> list = null;
		SqlSession session = MySqlSessionFactory.getSession();		
		try {
			list = dao.list(session);	
		} finally {
			session.close();
		}		
		return list;
	}

	@Override
	public int write(BoardDTO dto) {
		SqlSession session = MySqlSessionFactory.getSession();
		int n = 0;
		try {
			n = dao.write(session, dto);
			if(n ==1)session.commit();
			
		} finally {
			session.close();
		}
		return 0;
	}

	@Override
	public BoardDTO retireve(int num) {
		BoardDTO dto = null;	
		SqlSession session = MySqlSessionFactory.getSession();
		try {
			// 조회수 증가 
			int n = dao.readcnt(session, num);
			session.commit();
			
			// 글 자세히 보기
			dto = dao.retireve(session, num);
		} finally {
			session.close();
		}
		return dto;
	}

	@Override
	public int update(BoardDTO dto) {
		int n = 0;
		SqlSession session = MySqlSessionFactory.getSession();
		try {
			n = dao.update(session,dto);
			if(n==1)session.commit();
			
		} finally {
			session.close();
		}
		return n;
	}

	@Override
	public int delete(int num) {
		int n = 0;
		SqlSession session = MySqlSessionFactory.getSession();
		try {
			n = dao.delete(session,num);
			if(n==1)session.commit();			
		} finally {
			session.close();
		} 
		return 0;
	}
	
	

}
