package com.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import com.dao.BoardDAO;
import com.dto.BoardDTO;
import com.service.BoardService;
import com.service.BoardServiceImpl;

@WebServlet("/BoardRetrieveServlet")
public class BoardRetrieveServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		BoardService service = new BoardServiceImpl();
		service.setDao(new BoardDAO());
		
		int num = Integer.parseInt(request.getParameter("num"));
		System.out.println(num);
				
		
		BoardDTO dto = service.retireve(num);	
		
		request.setAttribute("retrieve", dto);
		request.getRequestDispatcher("retrieve.jsp").forward(request, response);
		
	}
}
