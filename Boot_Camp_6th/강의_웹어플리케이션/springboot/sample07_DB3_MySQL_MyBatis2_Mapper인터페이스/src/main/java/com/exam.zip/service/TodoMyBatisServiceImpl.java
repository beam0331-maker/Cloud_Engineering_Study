package com.exam.service;

import com.exam.dao.TodoMyBatisRepository;
import com.exam.dto.TodoDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("todoMyBatisService") // todoMyBatisService 필요없음
public class TodoMyBatisServiceImpl implements TodoMybatisService {

    TodoMyBatisRepository todoMyBatisRepository;
    public TodoMyBatisServiceImpl(TodoMyBatisRepository todoMyBatisRepository) {
        this.todoMyBatisRepository = todoMyBatisRepository;
    }

    @Override
    public List<TodoDTO> findAll() {
        return todoMyBatisRepository.findAll();
    }
}
