package com.exam.dao;

import com.exam.dto.TodoDTO;
import com.exam.service.TodoMybatisService;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class TodoMyBatisRepository {

    SqlSessionTemplate sqlSessionTemplate;
    public TodoMyBatisRepository(SqlSessionTemplate sqlSessionTemplate){
        this.sqlSessionTemplate=sqlSessionTemplate;
    };

    // 목롭보기
    public List<TodoDTO> findAll(){
        List<TodoDTO> list = sqlSessionTemplate.selectList("com.exam.config.TodoMapper.findAll");
        return list;
    }// end findAll
}
